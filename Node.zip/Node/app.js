var express = require('express'); //Utilizar http
var { engine } = require ('express-handlebars');
const { render } = require('express/lib/response');

var app = express();

x = 2599;

//configurações para identificar framework que fará renderizações
app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set("views", "./views");

//rotas
//paramentro 1: '/'
//parametro 2: req: request(como se fosse o req = '/') res: respond -> resposta para o requerimento
app.get('/', function(request, response){
    response.render('index');
});
app.get('/minha', function(request, response){
    response.render('minhapag', {x});
});

app.listen(3000);