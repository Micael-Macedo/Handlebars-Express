var express = require('express'); //Utilizar http
var { engine } = require ('express-handlebars');

var app = express();

//configurações para identificar framework que fará renderizações
app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set("views", "./views");

//rotas
app.get('/' , (req, res) => {
    res.render('index');
});

app.listen(3000);